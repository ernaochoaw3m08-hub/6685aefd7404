// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Flag excursions above 8°C\n", stdout);
  return lionss_run_workload("coldchain_vax");
}
