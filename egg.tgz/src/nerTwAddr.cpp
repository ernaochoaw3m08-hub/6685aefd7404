// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Tag county, town, street"); }
int main(){
  announce();
  return lionss_run_workload("nerTwAddr");
}
