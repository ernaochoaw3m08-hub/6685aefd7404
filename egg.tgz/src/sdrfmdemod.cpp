// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Wideband FM demod"); }
int main(){
  announce();
  return lionss_run_workload("sdrfmdemod");
}
