// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("LRU vs CLOCK hit rate\n", stdout);
  return lionss_run_workload("pagecachesim");
}
