// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Validate reachability and dead ends\n", stdout);
  return lionss_run_workload("dialoggraph");
}
