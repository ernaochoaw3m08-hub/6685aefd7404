// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Loop closure and pose graph optimize\n", stdout);
  return lionss_run_workload("Cinder");
}
