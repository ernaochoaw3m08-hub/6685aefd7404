// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Elevation profile with gain\n", stdout);
  return lionss_run_workload("elev-profile");
}
