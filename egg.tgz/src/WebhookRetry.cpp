// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Exponential backoff replay"); }
int main(){
  announce();
  return lionss_run_workload("WebhookRetry");
}
