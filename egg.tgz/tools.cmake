# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(yew src/yew.cpp)
set_property(TARGET yew PROPERTY CXX_STANDARD 11)
target_link_libraries(yew lionss pthread)

add_executable(barcode-verify src/barcode-verify.cpp)
set_property(TARGET barcode-verify PROPERTY CXX_STANDARD 11)
target_link_libraries(barcode-verify lionss pthread)

add_executable(nerTwAddr src/nerTwAddr.cpp)
set_property(TARGET nerTwAddr PROPERTY CXX_STANDARD 11)
target_link_libraries(nerTwAddr lionss pthread)

add_executable(seocrawl src/seocrawl.cpp)
set_property(TARGET seocrawl PROPERTY CXX_STANDARD 11)
target_link_libraries(seocrawl lionss pthread)

add_executable(quizforge src/quizforge.cpp)
set_property(TARGET quizforge PROPERTY CXX_STANDARD 11)
target_link_libraries(quizforge lionss pthread)

add_executable(harptuner src/harptuner.cpp)
set_property(TARGET harptuner PROPERTY CXX_STANDARD 11)
target_link_libraries(harptuner lionss pthread)

add_executable(elev-profile src/elev-profile.cpp)
set_property(TARGET elev-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(elev-profile lionss pthread)

add_executable(tenancyShard src/tenancyShard.cpp)
set_property(TARGET tenancyShard PROPERTY CXX_STANDARD 11)
target_link_libraries(tenancyShard lionss pthread)

add_executable(DialysisKtv src/DialysisKtv.cpp)
set_property(TARGET DialysisKtv PROPERTY CXX_STANDARD 11)
target_link_libraries(DialysisKtv lionss pthread)

add_executable(sagaOrders src/sagaOrders.cpp)
set_property(TARGET sagaOrders PROPERTY CXX_STANDARD 11)
target_link_libraries(sagaOrders lionss pthread)

add_executable(abtest-reader src/abtest-reader.cpp)
set_property(TARGET abtest-reader PROPERTY CXX_STANDARD 11)
target_link_libraries(abtest-reader lionss pthread)

add_executable(sdrfmdemod src/sdrfmdemod.cpp)
set_property(TARGET sdrfmdemod PROPERTY CXX_STANDARD 11)
target_link_libraries(sdrfmdemod lionss pthread)

add_executable(cdc-tailer src/cdc-tailer.cpp)
set_property(TARGET cdc-tailer PROPERTY CXX_STANDARD 11)
target_link_libraries(cdc-tailer lionss pthread)

add_executable(tex-thesis src/tex-thesis.cpp)
set_property(TARGET tex-thesis PROPERTY CXX_STANDARD 11)
target_link_libraries(tex-thesis lionss pthread)

add_executable(chash_ring src/chash_ring.cpp)
set_property(TARGET chash_ring PROPERTY CXX_STANDARD 11)
target_link_libraries(chash_ring lionss pthread)

add_executable(dialoggraph src/dialoggraph.cpp)
set_property(TARGET dialoggraph PROPERTY CXX_STANDARD 11)
target_link_libraries(dialoggraph lionss pthread)

add_executable(mealPlanner src/mealPlanner.cpp)
set_property(TARGET mealPlanner PROPERTY CXX_STANDARD 11)
target_link_libraries(mealPlanner lionss pthread)

add_executable(metroridership src/metroridership.cpp)
set_property(TARGET metroridership PROPERTY CXX_STANDARD 11)
target_link_libraries(metroridership lionss pthread)

add_executable(pagecachesim src/pagecachesim.cpp)
set_property(TARGET pagecachesim PROPERTY CXX_STANDARD 11)
target_link_libraries(pagecachesim lionss pthread)

add_executable(ocsp-stapler src/ocsp-stapler.cpp)
set_property(TARGET ocsp-stapler PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-stapler lionss pthread)

add_executable(license-scan src/license-scan.cpp)
set_property(TARGET license-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(license-scan lionss pthread)

add_executable(PhotoStitch src/PhotoStitch.cpp)
set_property(TARGET PhotoStitch PROPERTY CXX_STANDARD 11)
target_link_libraries(PhotoStitch lionss pthread)

add_executable(halcyon src/halcyon.cpp)
set_property(TARGET halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(halcyon lionss pthread)

add_executable(pdfformsfill src/pdfformsfill.cpp)
set_property(TARGET pdfformsfill PROPERTY CXX_STANDARD 11)
target_link_libraries(pdfformsfill lionss pthread)

add_executable(coldchain_vax src/coldchain_vax.cpp)
set_property(TARGET coldchain_vax PROPERTY CXX_STANDARD 11)
target_link_libraries(coldchain_vax lionss pthread)

add_executable(XfmrLoading src/XfmrLoading.cpp)
set_property(TARGET XfmrLoading PROPERTY CXX_STANDARD 11)
target_link_libraries(XfmrLoading lionss pthread)

add_executable(WebhookRetry src/WebhookRetry.cpp)
set_property(TARGET WebhookRetry PROPERTY CXX_STANDARD 11)
target_link_libraries(WebhookRetry lionss pthread)

add_executable(Cinder src/Cinder.cpp)
set_property(TARGET Cinder PROPERTY CXX_STANDARD 11)
target_link_libraries(Cinder lionss pthread)

add_executable(fuel-plan-rcss src/fuel-plan-rcss.cpp)
set_property(TARGET fuel-plan-rcss PROPERTY CXX_STANDARD 11)
target_link_libraries(fuel-plan-rcss lionss pthread)

add_executable(copperhead src/copperhead.cpp)
set_property(TARGET copperhead PROPERTY CXX_STANDARD 11)
target_link_libraries(copperhead lionss pthread)

