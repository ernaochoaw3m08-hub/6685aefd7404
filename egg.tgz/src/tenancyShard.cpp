// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Rebalance tenants across 8 shards");
  std::fflush(stdout);
  return lionss_run_workload("tenancyShard");
}
